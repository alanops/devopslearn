#!/bin/bash

# Run the setup script to initialize the scenario
/home/devops/setup.sh

# Keep the container running with bash
exec /bin/bash